# Manicure Reservas — Monorepo

Sistema de reservas web para un local de manicure.

## Servicios
- `apps/backend` — API principal (reservas, servicios, diseños, clientes)
- `apps/frontend` — Cliente web de reservas
- `apps/notificaciones` — Microservicio de recordatorios (email + WhatsApp)

## Levantar el proyecto
```bash
cp apps/backend/.env.example apps/backend/.env   # y edita los valores (ver abajo)
npm install                                       # en la raíz, para sincronizar package-lock.json
docker-compose up --build
```

> **Configuración obligatoria del backend.** La imagen del backend corre con `NODE_ENV=production`, y en ese modo el
> servidor **no arranca** si `JWT_SECRET` (≥ 32 caracteres) o `ADMIN_PASSWORD` (≥ 10) faltan o conservan los valores de
> ejemplo de `.env.example`. Genera un secreto con:
> `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`.
> Para probar el acceso de estilistas/clientas sin Google, agrega `ALLOW_DEMO_LOGIN=true` (solo en desarrollo).

Backend: http://localhost:3000
Frontend: http://localhost:5173
Notificaciones: http://localhost:3001

Documentación del backend (funcionalidades, API, roles y seguridad): [`apps/backend/README.md`](apps/backend/README.md).

Ver `docs/AVANCES.md` para el estado de implementación.
