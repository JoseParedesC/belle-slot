import axios from 'axios';
import { Usuario, Empleada, ReservaItem, Empresa, SlotHorario } from '../types';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export const api = axios.create({ baseURL: API_URL });

const TENANT_KEY = 'belle_slot_tenant_slug';
const TOKEN_KEY = 'belle_slot_token';
const USER_KEY = 'belle_slot_user';

export function obtenerTenantSlug(): string {
  if (typeof window === 'undefined') return 'belle-slot';
  const pathname = window.location.pathname;
  const parts = pathname.split('/').filter(Boolean);
  const knownPrefixes = ['estilistas', 'mis-citas', 'admin', 'explorar', 'salones', 'registro-salon'];

  if (parts.length > 0 && !knownPrefixes.includes(parts[0])) {
    const slugFromUrl = parts[0].toLowerCase();
    localStorage.setItem(TENANT_KEY, slugFromUrl);
    return slugFromUrl;
  }

  // Si está en la raíz '/', el slug corresponde a belle-slot
  if (parts.length === 0) {
    localStorage.setItem(TENANT_KEY, 'belle-slot');
    return 'belle-slot';
  }

  return localStorage.getItem(TENANT_KEY) || 'belle-slot';
}

export function guardarTenantSlug(slug: string) {
  localStorage.setItem(TENANT_KEY, slug.toLowerCase());
}

// Interceptor automático para enviar siempre el tenant y el token
api.interceptors.request.use((config) => {
  const currentSlug = obtenerTenantSlug();
  if (currentSlug) {
    config.headers['x-tenant-slug'] = currentSlug;
  }

  const token = obtenerToken();
  if (token && !config.headers['Authorization']) {
    config.headers['Authorization'] = `Bearer ${token}`;
  }

  return config;
});

// ---- SaaS Multi-Tenant Endpoints ----

export async function obtenerEmpresasSaaS(): Promise<Empresa[]> {
  const { data } = await api.get('/saas/empresas');
  return data;
}

export async function obtenerEmpresaPorSlug(slug: string): Promise<Empresa> {
  const { data } = await api.get(`/saas/empresas/${slug}`);
  return data;
}

export async function registrarNuevaEmpresa(payload: {
  nombre: string;
  slug?: string;
  direccion?: string;
  telefonoWhatsapp?: string;
  emailContacto?: string;
  horarioApertura?: string;
  horarioCierre?: string;
  diasAtencion?: string[];
  duracionBloqueMinutos?: number;
  horasAnticipacionCancelacion?: number;
  textoBannerPrecio?: string;
  adminNombre?: string;
  adminEmail?: string;
  adminPassword?: string;
}) {
  const { data } = await api.post('/saas/empresas', payload);
  return data;
}

// ---- Servicios, Diseños y Configuración del Salón Activo ----

export async function obtenerServicios() {
  const { data } = await api.get('/servicios');
  return data;
}

export async function obtenerDisenos(servicioId: string) {
  const { data } = await api.get(`/servicios/${servicioId}/disenos`);
  return data;
}

export async function obtenerConfiguracion() {
  const { data } = await api.get('/configuracion');
  return data;
}

// ---- Configuración de Disponibilidad (Admin) ----

export async function obtenerConfiguracionAdmin() {
  const { data } = await api.get('/admin/configuracion', { headers: authHeaders() });
  return data;
}

export async function actualizarConfiguracionAdmin(payload: {
  horarioApertura?: string;
  horarioCierre?: string;
  diasAtencion?: string[];
  duracionBloqueMinutos?: number;
  horasAnticipacionCancelacion?: number;
  personalizacion?: any;
}) {
  const { data } = await api.patch('/admin/configuracion', payload, { headers: authHeaders() });
  return data;
}

export async function obtenerDisponibilidad(fecha: string, servicioId: string) {
  const { data } = await api.get('/disponibilidad', {
    params: { fecha, servicio_id: servicioId },
  });
  return data.horarios_disponibles as string[];
}

/**
 * Todas las horas del día dentro de los rangos configurados, con su estado (disponible / bloqueada).
 * Con `empleadaId` devuelve la agenda de esa profesional; sin él, "cualquiera disponible".
 */
export async function obtenerHorariosDia(fecha: string, servicioId: string, empleadaId?: string | null) {
  const params: Record<string, string> = { fecha, servicio_id: servicioId };
  if (empleadaId) params.empleada_id = empleadaId;
  const { data } = await api.get('/disponibilidad', { params });
  return (data.horarios || []) as SlotHorario[];
}

/** Profesionales activas del salón para elegir al agendar (solo id y nombre). */
export async function obtenerEmpleadasParaReserva(): Promise<Array<{ id: string; nombre: string }>> {
  const { data } = await api.get('/empleadas');
  return data;
}

export async function crearReserva(payload: {
  cliente: { nombre: string; telefono: string; email?: string };
  servicio_id: string;
  diseno_id?: string;
  empleada_id?: string;
  fecha: string;
  hora_inicio: string;
}) {
  const { data } = await api.post('/reservas', payload);
  return data;
}

/** Reservas de la clienta con sesión iniciada (el servidor usa el correo de la sesión, no un parámetro). */
export async function obtenerMisReservas(): Promise<ReservaItem[]> {
  const { data } = await api.get('/reservas/cliente/mis-reservas', { headers: authHeaders() });
  return data;
}

// ---- Autenticación y Usuario ----

export function guardarToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem('admin_token', token);
}

export function obtenerToken(): string | null {
  return localStorage.getItem(TOKEN_KEY) || localStorage.getItem('admin_token');
}

export function guardarUsuarioActual(usuario: Usuario) {
  localStorage.setItem(USER_KEY, JSON.stringify(usuario));
}

export function obtenerUsuarioActual(): Usuario | null {
  const data = localStorage.getItem(USER_KEY);
  if (!data) return null;
  try {
    return JSON.parse(data) as Usuario;
  } catch {
    return null;
  }
}

export function cerrarSesion() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  localStorage.removeItem('admin_token');
}

export function authHeaders() {
  const token = obtenerToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function login(usuario: string, password: string) {
  const { data } = await api.post('/auth/login', { usuario, password });
  if (data.token) {
    guardarToken(data.token);
  }
  if (data.usuario) {
    guardarUsuarioActual(data.usuario);
  }
  return data;
}

export async function loginConGoogle(payload: {
  credential?: string;
  rol: 'estilista' | 'cliente';
  email?: string;
  nombre?: string;
  foto?: string;
  telefono?: string;
}) {
  const { data } = await api.post('/auth/google', payload);
  if (data.token) {
    guardarToken(data.token);
  }
  if (data.usuario) {
    guardarUsuarioActual(data.usuario);
  }
  return data;
}

export async function obtenerEstilistas(): Promise<Empleada[]> {
  const { data } = await api.get('/auth/estilistas', { headers: authHeaders() });
  return data;
}

export interface FiltrosReservasAdmin {
  fecha?: string;
  fecha_inicio?: string;
  fecha_fin?: string;
  cliente?: string;
  servicio_id?: string;
  empleada_id?: string;
  estado?: string;
}

export async function obtenerReservasAdmin(
  fechaOFiltros?: string | FiltrosReservasAdmin,
  empleadaId?: string
): Promise<ReservaItem[]> {
  let params: any = {};
  if (typeof fechaOFiltros === 'string') {
    if (fechaOFiltros) params.fecha = fechaOFiltros;
    if (empleadaId) params.empleada_id = empleadaId;
  } else if (fechaOFiltros && typeof fechaOFiltros === 'object') {
    params = { ...fechaOFiltros };
  }

  const { data } = await api.get('/admin/reservas', {
    params,
    headers: authHeaders(),
  });
  return data;
}

export async function cambiarEstadoReservaAdmin(id: string, estado: 'completada' | 'no_asistio' | 'cancelada') {
  const { data } = await api.patch(
    `/admin/reservas/${id}/estado`,
    { estado },
    { headers: authHeaders() }
  );
  return data;
}

export async function obtenerEstilistasAdmin(): Promise<Empleada[]> {
  const { data } = await api.get('/admin/estilistas', { headers: authHeaders() });
  return data;
}

export async function crearEstilistaAdmin(payload: { nombre: string; email: string; telefono?: string }) {
  const { data } = await api.post('/admin/estilistas', payload, { headers: authHeaders() });
  return data;
}

export async function cambiarEstadoEstilistaAdmin(id: string, activo: boolean) {
  const { data } = await api.patch(`/admin/estilistas/${id}/estado`, { activo }, { headers: authHeaders() });
  return data;
}

export async function obtenerReporteOcupacion() {
  const { data } = await api.get('/admin/reportes/ocupacion', { headers: authHeaders() });
  return data;
}
