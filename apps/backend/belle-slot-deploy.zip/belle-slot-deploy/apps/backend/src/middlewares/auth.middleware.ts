import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';

export type RolToken = 'admin' | 'superadmin' | 'admin_empresa' | 'estilista' | 'cliente';

export interface TokenPayload {
  id?: string;
  usuario?: string;
  email?: string;
  rol: RolToken;
  empresaId?: string | null;
  foto?: string;
}

declare global {
  namespace Express {
    interface Request {
      auth?: TokenPayload;
    }
  }
}

/** Roles que administran el salón (configuración, clientas, estilistas, reportes). */
export const ROLES_GESTION: RolToken[] = ['admin', 'admin_empresa', 'superadmin'];

/** Roles que pueden ver y gestionar la agenda de reservas (gestión + estilistas). */
export const ROLES_AGENDA: RolToken[] = [...ROLES_GESTION, 'estilista'];

export function firmarToken(payload: TokenPayload, expiresIn: '12h' | '24h'): string {
  return jwt.sign(payload, env.JWT_SECRET, { algorithm: 'HS256', expiresIn });
}

/** Lee y valida el JWT del header `Authorization: Bearer <token>`. Devuelve null si no es válido. */
export function leerToken(req: Request): TokenPayload | null {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) return null;

  try {
    const decodificado = jwt.verify(header.slice(7).trim(), env.JWT_SECRET, { algorithms: ['HS256'] });
    if (typeof decodificado === 'string' || !decodificado.rol) return null;
    return decodificado as unknown as TokenPayload;
  } catch {
    return null;
  }
}

/**
 * Exige un JWT válido y que pertenezca al salón de la petición.
 * Debe ejecutarse DESPUÉS de resolverTenant. Un token solo sirve en el salón donde se emitió
 * (el superadmin puede operar en cualquiera).
 */
export function requiereAutenticacion(req: Request, res: Response, next: NextFunction) {
  const auth = leerToken(req);
  if (!auth) return res.status(401).json({ error: 'No autenticado' });

  if (auth.rol !== 'superadmin' && req.empresa && auth.empresaId !== req.empresa.id) {
    return res.status(403).json({ error: 'No tienes acceso a este salón' });
  }

  req.auth = auth;
  next();
}

/** Exige que el usuario autenticado tenga alguno de los roles indicados. */
export function requiereRol(...roles: RolToken[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth || !roles.includes(req.auth.rol)) {
      return res.status(403).json({ error: 'No tienes permisos para realizar esta acción' });
    }
    next();
  };
}
