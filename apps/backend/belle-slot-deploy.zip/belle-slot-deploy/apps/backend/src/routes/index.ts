import { Router } from 'express';
import { saasRouter } from '../modules/saas/saas.controller';
import { resolverTenant } from '../middlewares/tenant.middleware';
import { requiereAutenticacion, requiereRol, ROLES_GESTION } from '../middlewares/auth.middleware';
import { servicioRouter } from '../modules/servicios/servicio.controller';
import { disenoRouter } from '../modules/disenos/diseno.controller';
import { clienteRouter } from '../modules/clientes/cliente.controller';
import { reservaRouter, adminReservaRouter } from '../modules/reservas/reserva.controller';
import { configuracionRouter } from '../modules/configuracion/configuracion.controller';
import { authRouter, adminEstilistasRouter } from '../modules/auth/auth.controller';
import { empleadaRouter } from '../modules/empleadas/empleada.controller';

// ---------------------------------------------------------------------------
// API pública (/api). Solo lecturas necesarias para agendar; las escrituras de
// servicios, diseños y configuración exigen sesión de gestión (ver cada router).
// ---------------------------------------------------------------------------
export const apiRouter = Router();

// Rutas SaaS globales (directorio de salones, registro de nuevo salón)
apiRouter.use('/saas', saasRouter);

// Middleware de resolución de Tenant para todas las operaciones de salón
apiRouter.use(resolverTenant);

apiRouter.use('/auth', authRouter);
apiRouter.use('/servicios', servicioRouter);
apiRouter.use('/disenos', disenoRouter);
apiRouter.use('/empleadas', empleadaRouter);
apiRouter.use('/configuracion', configuracionRouter);
apiRouter.use('/', reservaRouter); // expone /disponibilidad y /reservas

// ---------------------------------------------------------------------------
// Administración (/api/admin). Orden obligatorio:
//   1. resolverTenant        -> identifica el salón de la petición
//   2. requiereAutenticacion -> JWT válido Y emitido para ese salón
//   3. requiereRol           -> permisos según el recurso
// ---------------------------------------------------------------------------
export const adminRouter = Router();

adminRouter.use(resolverTenant);
adminRouter.use(requiereAutenticacion);

// Agenda: personal de gestión y estilistas (el rol se exige dentro de cada ruta)
adminRouter.use('/', adminReservaRouter);

// Solo gestión del salón
adminRouter.use('/clientes', requiereRol(...ROLES_GESTION), clienteRouter);
adminRouter.use('/estilistas', requiereRol(...ROLES_GESTION), adminEstilistasRouter);
adminRouter.use('/configuracion', requiereRol(...ROLES_GESTION), configuracionRouter);
