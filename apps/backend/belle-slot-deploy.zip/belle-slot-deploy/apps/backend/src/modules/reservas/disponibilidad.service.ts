import { prisma } from '../../config/database';

// ---------------------------------------------------------------------------
// Tipos
// ---------------------------------------------------------------------------

export interface Turno {
  inicio: string; // "HH:mm"
  fin: string; // "HH:mm"
}

export type MotivoBloqueo = 'ocupado' | 'pasada';

export interface SlotHorario {
  hora: string; // "HH:mm" (hora de inicio de la cita)
  disponible: boolean;
  motivo?: MotivoBloqueo; // solo presente cuando disponible === false
}

/** Cita ya reservada, en minutos desde medianoche. `empleadaId` es null si nunca se asignó a una profesional. */
export interface CitaOcupada {
  inicio: number;
  fin: number;
  empleadaId: string | null;
}

export interface OpcionesAgenda {
  /** IDs de las profesionales activas del salón. Vacío = el salón no maneja agenda por profesional. */
  empleadasActivas: string[];
  /** Si se indica, se calcula la agenda de esa profesional; si no, "cualquiera disponible". */
  empleadaId?: string;
  /** Las horas de inicio anteriores a este valor (en minutos) se marcan como 'pasada'. */
  minutosMinimos?: number;
}

// ---------------------------------------------------------------------------
// Utilidades de tiempo (puras, sin acceso a base de datos)
// ---------------------------------------------------------------------------

/** Convierte "HH:mm" a minutos desde medianoche */
export function aMinutos(hora: string): number {
  const [h, m] = hora.split(':').map(Number);
  return h * 60 + m;
}

/** Convierte minutos desde medianoche a "HH:mm" */
export function aHora(minutos: number): string {
  const h = Math.floor(minutos / 60).toString().padStart(2, '0');
  const m = (minutos % 60).toString().padStart(2, '0');
  return `${h}:${m}`;
}

function normalizarTexto(txt: string): string {
  return txt
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

const DIAS_SEMANA = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];

/**
 * Fecha y hora actuales en la zona horaria del negocio (el servidor en Railway
 * corre en UTC, así que no se puede usar new Date() directamente para comparar
 * contra las horas del salón). Configurable con la variable TIMEZONE_NEGOCIO.
 */
function ahoraEnZonaNegocio(): { fecha: string; minutos: number } {
  const timeZone = process.env.TIMEZONE_NEGOCIO || 'America/Bogota';
  const partes = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(new Date());

  const get = (tipo: string) => partes.find((p) => p.type === tipo)?.value || '0';
  return {
    fecha: `${get('year')}-${get('month')}-${get('day')}`,
    minutos: Number(get('hour')) * 60 + Number(get('minute')),
  };
}

// ---------------------------------------------------------------------------
// Funciones reutilizables de cálculo (puras)
// ---------------------------------------------------------------------------

/**
 * Determina si el salón atiende el día de la semana de `fecha` (YYYY-MM-DD).
 * Si no hay `diasAtencion` configurado se asume que atiende todos los días.
 */
export function atiendeEnFecha(diasAtencion: unknown, fecha: string): boolean {
  if (!Array.isArray(diasAtencion) || diasAtencion.length === 0) return true;

  const [year, month, day] = fecha.split('-').map(Number);
  const diaNombre = DIAS_SEMANA[new Date(year, month - 1, day).getDay()];
  return diasAtencion.some((d: string) => normalizarTexto(d) === diaNombre);
}

/**
 * Resuelve los turnos de atención (rangos de horas) para un mes dado.
 * Prioridad: temporada estacional > turnos directos > pausa de almuerzo > horario continuo.
 * Cada turno es un rango independiente, por lo que los espacios entre turnos
 * (ej. la hora de almuerzo) nunca generan horas reservables.
 */
export function resolverTurnos(config: any, mes: number): Turno[] {
  const personalizacion =
    (typeof config?.personalizacion === 'string'
      ? JSON.parse(config.personalizacion)
      : config?.personalizacion) || {};

  // 1. Temporadas estacionales
  if (
    personalizacion.horarioEstacional?.activo &&
    Array.isArray(personalizacion.horarioEstacional.temporadas)
  ) {
    const temporada = personalizacion.horarioEstacional.temporadas.find(
      (t: any) => Array.isArray(t.meses) && t.meses.includes(mes)
    );
    if (temporada && Array.isArray(temporada.turnos) && temporada.turnos.length > 0) {
      return temporada.turnos;
    }
  }

  // 2. Turnos preconfigurados directamente
  if (Array.isArray(personalizacion.turnos) && personalizacion.turnos.length > 0) {
    return personalizacion.turnos;
  }

  // 3. Pausa de almuerzo explícita sobre el horario general
  const horaApertura = config?.horarioApertura || '09:00';
  const horaCierre = config?.horarioCierre || '18:00';
  if (personalizacion.pausaAlmuerzo?.inicio && personalizacion.pausaAlmuerzo?.fin) {
    return [
      { inicio: horaApertura, fin: personalizacion.pausaAlmuerzo.inicio },
      { inicio: personalizacion.pausaAlmuerzo.fin, fin: horaCierre },
    ];
  }

  // 4. Horario continuo tradicional
  return [{ inicio: horaApertura, fin: horaCierre }];
}

/**
 * Genera TODAS las horas de inicio posibles dentro de los turnos configurados:
 * una cita que empieza en `inicio` debe terminar (inicio + duración) dentro del mismo turno.
 */
export function generarHorasDeInicio(turnos: Turno[], duracionMinutos: number, bloqueMinutos: number): string[] {
  const horas: string[] = [];
  for (const turno of turnos) {
    const inicioTurno = aMinutos(turno.inicio);
    const finTurno = aMinutos(turno.fin);
    for (let inicio = inicioTurno; inicio + duracionMinutos <= finTurno; inicio += bloqueMinutos) {
      horas.push(aHora(inicio));
    }
  }
  return horas.sort();
}

function ocupacionEnRango(inicio: number, fin: number, citas: CitaOcupada[], empleadasActivas: string[]) {
  const solapadas = citas.filter((c) => inicio < c.fin && fin > c.inicio);
  const ocupadas = new Set(solapadas.filter((c) => c.empleadaId).map((c) => c.empleadaId as string));
  return {
    solapadas,
    // Profesionales activas sin ninguna cita que se cruce con este rango
    libres: empleadasActivas.filter((id) => !ocupadas.has(id)),
    // Citas antiguas sin profesional asignada: consumen una plaza de "cualquiera disponible"
    sinAsignar: solapadas.filter((c) => !c.empleadaId).length,
  };
}

/**
 * Marca cada hora de inicio como disponible o bloqueada. Función pura: no consulta la base de datos.
 *
 *  - Sin profesionales activas (`empleadasActivas` vacío): cualquier cita que se cruce bloquea la hora (agenda del salón).
 *  - Con `empleadaId`: solo bloquean las citas de esa profesional.
 *  - Sin `empleadaId` ("cualquiera"): la hora está disponible mientras al menos una profesional esté libre.
 *  - Las horas anteriores a `minutosMinimos` (hoy, ya transcurridas) se marcan como 'pasada'.
 */
export function marcarBloqueos(
  horas: string[],
  duracionMinutos: number,
  citas: CitaOcupada[],
  opciones: OpcionesAgenda
): SlotHorario[] {
  const { empleadasActivas, empleadaId, minutosMinimos } = opciones;

  return horas.map((hora) => {
    const inicio = aMinutos(hora);
    const fin = inicio + duracionMinutos;

    if (minutosMinimos !== undefined && inicio < minutosMinimos) {
      return { hora, disponible: false, motivo: 'pasada' as const };
    }

    const { solapadas, libres, sinAsignar } = ocupacionEnRango(inicio, fin, citas, empleadasActivas);

    let ocupado: boolean;
    if (empleadasActivas.length === 0) {
      ocupado = solapadas.length > 0;
    } else if (empleadaId) {
      ocupado = solapadas.some((c) => c.empleadaId === empleadaId);
    } else {
      ocupado = libres.length - sinAsignar <= 0;
    }

    return ocupado ? { hora, disponible: false, motivo: 'ocupado' as const } : { hora, disponible: true };
  });
}

/**
 * Elige la profesional que atenderá una cita cuando la clienta no escogió ninguna:
 * entre las que están libres en ese rango, la que tenga menos citas ese día (empate: orden de la lista).
 * Devuelve null si no hay ninguna libre.
 */
export function elegirEmpleadaLibre(
  hora: string,
  duracionMinutos: number,
  citas: CitaOcupada[],
  empleadasActivas: string[]
): string | null {
  const inicio = aMinutos(hora);
  const { libres, sinAsignar } = ocupacionEnRango(inicio, inicio + duracionMinutos, citas, empleadasActivas);
  if (libres.length - sinAsignar <= 0) return null;

  const cargaDelDia = (id: string) => citas.filter((c) => c.empleadaId === id).length;
  return [...libres].sort((x, y) => cargaDelDia(x) - cargaDelDia(y))[0];
}

// ---------------------------------------------------------------------------
// Funciones con acceso a base de datos
// ---------------------------------------------------------------------------

/**
 * Carga todo lo necesario para calcular la agenda de un día: servicio, configuración,
 * profesionales activas y citas ya reservadas.
 */
async function cargarAgenda(fecha: string, servicioId: string, empresaId?: string, empleadaId?: string) {
  const servicio = await prisma.servicio.findUnique({ where: { id: servicioId } });
  if (!servicio) throw new Error('Servicio no encontrado');

  const resolvedEmpresaId = empresaId || servicio.empresaId;
  let config: any = null;

  if (resolvedEmpresaId) {
    config = await prisma.empresa.findUnique({ where: { id: resolvedEmpresaId } });
  }
  if (!config) {
    config = await prisma.configuracionNegocio.findFirst();
  }

  // Profesionales activas del salón (define si la agenda es por profesional o del salón completo)
  let empleadasActivas: string[] = [];
  if (resolvedEmpresaId) {
    const empleadas = await prisma.empleada.findMany({
      where: { empresaId: resolvedEmpresaId, activo: true },
      select: { id: true },
      orderBy: { nombre: 'asc' },
    });
    empleadasActivas = empleadas.map((e) => e.id);
  }

  if (empleadaId && !empleadasActivas.includes(empleadaId)) {
    throw new Error('La profesional seleccionada no está disponible');
  }

  const duracion = servicio.duracionMinutos;
  const vacia = { slots: [] as SlotHorario[], citas: [] as CitaOcupada[], empleadasActivas, duracion };

  // Día en que el salón no atiende
  if (!atiendeEnFecha(config?.diasAtencion, fecha)) {
    return vacia;
  }

  const mes = Number(fecha.split('-')[1]);
  const turnos = resolverTurnos(config, mes);
  const bloque = config?.duracionBloqueMinutos || 30;
  const horas = generarHorasDeInicio(turnos, duracion, bloque);

  // Citas ya reservadas ese día (las canceladas no bloquean)
  const whereReservas: any = {
    fecha: new Date(fecha),
    estado: { in: ['pendiente', 'confirmada'] },
  };
  if (resolvedEmpresaId) {
    whereReservas.empresaId = resolvedEmpresaId;
  }
  const reservasDelDia = await prisma.reserva.findMany({ where: whereReservas });

  const citas: CitaOcupada[] = reservasDelDia.map((r) => ({
    inicio: aMinutos(r.horaInicio),
    fin: aMinutos(r.horaFin),
    empleadaId: r.empleadaId,
  }));

  // Hoy, las horas que ya pasaron también quedan bloqueadas; una fecha pasada queda bloqueada por completo
  const ahora = ahoraEnZonaNegocio();
  let minutosMinimos: number | undefined;
  if (fecha < ahora.fecha) minutosMinimos = 24 * 60;
  else if (fecha === ahora.fecha) minutosMinimos = ahora.minutos;

  const slots = marcarBloqueos(horas, duracion, citas, { empleadasActivas, empleadaId, minutosMinimos });
  return { slots, citas, empleadasActivas, duracion };
}

/**
 * Devuelve TODAS las horas de inicio del día dentro de los rangos configurados,
 * indicando cuáles están disponibles y cuáles bloqueadas (por otra cita o por haber pasado ya).
 * Con `empleadaId` calcula la agenda de esa profesional; sin él, "cualquiera disponible".
 * Un día en que el salón no atiende devuelve una lista vacía.
 */
export async function calcularSlotsDelDia(
  fecha: string,
  servicioId: string,
  empresaId?: string,
  empleadaId?: string
): Promise<SlotHorario[]> {
  const agenda = await cargarAgenda(fecha, servicioId, empresaId, empleadaId);
  return agenda.slots;
}

/**
 * Solo las horas de inicio disponibles (string[]).
 */
export async function calcularDisponibilidad(
  fecha: string,
  servicioId: string,
  empresaId?: string,
  empleadaId?: string
) {
  const slots = await calcularSlotsDelDia(fecha, servicioId, empresaId, empleadaId);
  return slots.filter((s) => s.disponible).map((s) => s.hora);
}

/**
 * Revalida una hora en el servidor y resuelve qué profesional atenderá la cita:
 * la elegida por la clienta o, si no eligió, la que esté libre con menos carga ese día.
 * Devuelve `empleadaId: null` cuando el salón no tiene profesionales registradas.
 */
export async function resolverAsignacion(
  fecha: string,
  servicioId: string,
  horaInicio: string,
  empresaId?: string,
  empleadaId?: string
): Promise<{ disponible: boolean; empleadaId: string | null }> {
  const agenda = await cargarAgenda(fecha, servicioId, empresaId, empleadaId);
  const slot = agenda.slots.find((s) => s.hora === horaInicio);
  if (!slot || !slot.disponible) return { disponible: false, empleadaId: null };

  if (empleadaId) return { disponible: true, empleadaId };

  const asignada =
    agenda.empleadasActivas.length > 0
      ? elegirEmpleadaLibre(horaInicio, agenda.duracion, agenda.citas, agenda.empleadasActivas)
      : null;
  return { disponible: true, empleadaId: asignada };
}

export function calcularHoraFin(horaInicio: string, duracionMinutos: number): string {
  return aHora(aMinutos(horaInicio) + duracionMinutos);
}
