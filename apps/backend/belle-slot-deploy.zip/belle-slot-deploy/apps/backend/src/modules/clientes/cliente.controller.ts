import { Router } from 'express';
import { prisma } from '../../config/database';
import { asyncHandler } from '../../utils/async-handler';

export const clienteRouter = Router();

// Busca un cliente existente por teléfono en la empresa o lo crea si no existe
export async function buscarOCrearCliente(
  data: { nombre: string; telefono: string; email?: string },
  empresaId?: string
) {
  const where: any = { telefono: data.telefono };
  if (empresaId) where.empresaId = empresaId;

  const existente = await prisma.cliente.findFirst({ where });
  if (existente) return existente;

  return prisma.cliente.create({
    data: {
      ...data,
      empresaId,
    },
  });
}

// Los routers de clientas se montan solo bajo /api/admin (requieren sesión de gestión).
clienteRouter.get('/', asyncHandler(async (req, res) => {
  const where: any = {};
  if (req.empresa?.id) where.empresaId = req.empresa.id;

  const clientes = await prisma.cliente.findMany({
    where,
    orderBy: { fechaRegistro: 'desc' },
  });
  res.json(clientes);
}));

clienteRouter.get('/:id', asyncHandler(async (req, res) => {
  // Se filtra por empresa: no se puede consultar una clienta de otro salón conociendo su id
  const cliente = await prisma.cliente.findFirst({
    where: { id: req.params.id, ...(req.empresa?.id ? { empresaId: req.empresa.id } : {}) },
    include: { reservas: true },
  });
  if (!cliente) return res.status(404).json({ error: 'Cliente no encontrado' });
  res.json(cliente);
}));
