import { Router } from 'express';
import { prisma } from '../../config/database';

export const empleadaRouter = Router();

// GET /api/empleadas -> profesionales activas del salón para elegir al agendar.
// Solo expone id y nombre (nunca correo ni teléfono, a diferencia de /api/auth/estilistas).
empleadaRouter.get('/', async (req, res) => {
  try {
    const where: any = { activo: true };
    if (req.empresa?.id) {
      where.empresaId = req.empresa.id;
    }

    const empleadas = await prisma.empleada.findMany({
      where,
      select: { id: true, nombre: true },
      orderBy: { nombre: 'asc' },
    });
    res.json(empleadas);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});
