import { prisma } from '../../config/database';
import { resolverAsignacion, calcularHoraFin } from './disponibilidad.service';
import { buscarOCrearCliente } from '../clientes/cliente.controller';
import { notificarConfirmacionReserva } from '../notificaciones/notificaciones.client';

interface CrearReservaInput {
  cliente: { nombre: string; telefono: string; email?: string };
  servicioId: string;
  disenoId?: string;
  empleadaId?: string;
  fecha: string;
  horaInicio: string;
  empresaId?: string;
}

export async function crearReserva(input: CrearReservaInput) {
  const { cliente, servicioId, disenoId, empleadaId, fecha, horaInicio, empresaId } = input;

  const servicio = await prisma.servicio.findUnique({ where: { id: servicioId } });
  if (!servicio) throw new Error('Servicio no encontrado');

  const resolvedEmpresaId = empresaId || servicio.empresaId;

  // Revalidar disponibilidad en el servidor (nunca confiar solo en el frontend)
  // y resolver qué profesional atenderá: la elegida por la clienta o la que esté libre con menos carga
  const asignacion = await resolverAsignacion(
    fecha,
    servicioId,
    horaInicio,
    resolvedEmpresaId || undefined,
    empleadaId
  );
  if (!asignacion.disponible) {
    throw new Error(
      empleadaId
        ? 'El horario seleccionado ya no está disponible con esta profesional'
        : 'El horario seleccionado ya no está disponible'
    );
  }

  let precioEstimado = Number(servicio.precioBase);
  if (disenoId) {
    const diseno = await prisma.diseno.findUnique({ where: { id: disenoId } });
    if (diseno) precioEstimado += Number(diseno.incrementoPrecio);
  }

  const horaFin = calcularHoraFin(horaInicio, servicio.duracionMinutos);
  const clienteRegistrado = await buscarOCrearCliente(cliente, resolvedEmpresaId || undefined);

  const reserva = await prisma.reserva.create({
    data: {
      empresaId: resolvedEmpresaId,
      clienteId: clienteRegistrado.id,
      servicioId,
      disenoId,
      empleadaId: asignacion.empleadaId ?? undefined,
      fecha: new Date(fecha),
      horaInicio,
      horaFin,
      precioEstimado,
      estado: 'pendiente',
    },
  });

  // Disparar notificación de confirmación (no bloquear la respuesta si falla)
  notificarConfirmacionReserva(reserva, clienteRegistrado, servicio).catch((err) =>
    console.error('Error notificando confirmación de reserva:', err.message)
  );

  return reserva;
}

export type EstadoReservaValor = 'pendiente' | 'confirmada' | 'completada' | 'cancelada' | 'no_asistio';

/** Busca una reserva SOLO dentro del salón indicado (evita acceder a reservas de otros salones por id). */
export async function obtenerReserva(id: string, empresaId?: string) {
  return prisma.reserva.findFirst({
    where: { id, ...(empresaId ? { empresaId } : {}) },
    include: { cliente: true, servicio: true, diseno: true, empleada: true },
  });
}

export async function cancelarReserva(id: string, empresaId: string | undefined, motivo?: string) {
  const existente = await obtenerReserva(id, empresaId);
  if (!existente) throw new Error('Reserva no encontrada');

  if (existente.estado === 'completada' || existente.estado === 'no_asistio') {
    throw new Error('No se puede cancelar una reserva ya finalizada');
  }
  if (existente.estado === 'cancelada') return existente;

  return prisma.reserva.update({
    where: { id },
    data: {
      estado: 'cancelada',
      fechaCancelacion: new Date(),
      motivoCancelacion: typeof motivo === 'string' ? motivo.slice(0, 500) : undefined,
    },
  });
}

export async function cambiarEstadoReserva(id: string, estado: EstadoReservaValor, empresaId?: string) {
  const existente = await obtenerReserva(id, empresaId);
  if (!existente) throw new Error('Reserva no encontrada');

  const reserva = await prisma.reserva.update({
    where: { id },
    data: {
      estado,
      ...(estado === 'cancelada' && existente.estado !== 'cancelada' ? { fechaCancelacion: new Date() } : {}),
    },
  });

  // Solo suma la inasistencia la primera vez que se marca (evita inflar el contador al repetir la petición)
  if (estado === 'no_asistio' && existente.estado !== 'no_asistio') {
    await prisma.cliente.update({
      where: { id: reserva.clienteId },
      data: { cantidadInasistencias: { increment: 1 } },
    });
  }

  return reserva;
}
