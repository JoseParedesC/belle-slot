import { Router } from 'express';
import { prisma } from '../../config/database';
import { calcularSlotsDelDia } from './disponibilidad.service';
import { crearReserva, cancelarReserva, obtenerReserva, cambiarEstadoReserva } from './reserva.service';
import { crearReservaSchema, estadoReservaSchema, ESTADOS_RESERVA } from './reserva.schema';
import {
  requiereAutenticacion,
  requiereRol,
  ROLES_AGENDA,
  ROLES_GESTION,
} from '../../middlewares/auth.middleware';
import { asyncHandler } from '../../utils/async-handler';

const FECHA_ISO = /^\d{4}-\d{2}-\d{2}$/;

export const reservaRouter = Router();
export const adminReservaRouter = Router();

// GET /api/disponibilidad?fecha=YYYY-MM-DD&servicio_id=...&empleada_id=... (empleada_id es opcional)
reservaRouter.get('/disponibilidad', async (req, res) => {
  try {
    const { fecha, servicio_id, empleada_id } = req.query as {
      fecha: string;
      servicio_id: string;
      empleada_id?: string;
    };
    if (!fecha || !servicio_id) {
      return res.status(400).json({ error: 'fecha y servicio_id son requeridos' });
    }
    const slots = await calcularSlotsDelDia(fecha, servicio_id, req.empresa?.id, empleada_id || undefined);
    res.json({
      fecha,
      servicio_id,
      empleada_id: empleada_id || null,
      // Todas las horas dentro de los rangos configurados, con su estado (disponible / bloqueada)
      horarios: slots,
      // Solo las disponibles (compatibilidad con clientes anteriores)
      horarios_disponibles: slots.filter((s) => s.disponible).map((s) => s.hora),
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// POST /api/reservas
reservaRouter.post('/reservas', async (req, res) => {
  const parsed = crearReservaSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(', ') });
  }
  try {
    const { cliente, servicio_id, diseno_id, empleada_id, fecha, hora_inicio } = parsed.data;
    const reserva = await crearReserva({
      cliente,
      servicioId: servicio_id,
      disenoId: diseno_id,
      empleadaId: empleada_id,
      fecha,
      horaInicio: hora_inicio,
      empresaId: req.empresa?.id,
    });
    res.status(201).json(reserva);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// GET /api/reservas/cliente/mis-reservas
// Requiere sesión. Una clienta solo ve SUS reservas (por el correo de su sesión); el personal de gestión
// puede consultar por ?email= o ?telefono=. Antes era público: cualquiera podía ver las citas de otra persona.
reservaRouter.get(
  '/reservas/cliente/mis-reservas',
  requiereAutenticacion,
  asyncHandler(async (req, res) => {
    const auth = req.auth!;
    const cliente: any = {};

    if (auth.rol === 'cliente') {
      if (!auth.email) return res.status(403).json({ error: 'Sesión sin correo asociado' });
      cliente.email = { equals: auth.email, mode: 'insensitive' };
    } else if (ROLES_GESTION.includes(auth.rol)) {
      const { email, telefono } = req.query as { email?: string; telefono?: string };
      if (!email && !telefono) {
        return res.status(400).json({ error: 'Debes proporcionar email o teléfono' });
      }
      if (email) cliente.email = { equals: email, mode: 'insensitive' };
      if (telefono) cliente.telefono = telefono;
    } else {
      return res.status(403).json({ error: 'No tienes permisos para realizar esta acción' });
    }

    const where: any = { cliente };
    if (req.empresa?.id) {
      where.empresaId = req.empresa.id;
    }

    const reservas = await prisma.reserva.findMany({
      where,
      include: {
        servicio: true,
        diseno: true,
        empleada: true,
      },
      orderBy: [{ fecha: 'desc' }, { horaInicio: 'desc' }],
    });
    res.json(reservas);
  })
);

/** ¿Puede este usuario ver/cancelar la reserva? Personal del salón, o la clienta dueña de la cita. */
function esDuenaOPersonal(req: any, reserva: { cliente?: { email?: string | null } | null }) {
  const auth = req.auth!;
  if (ROLES_AGENDA.includes(auth.rol)) return true;
  return (
    auth.rol === 'cliente' &&
    !!auth.email &&
    !!reserva.cliente?.email &&
    reserva.cliente.email.toLowerCase() === auth.email.toLowerCase()
  );
}

// GET /api/reservas/:id (requiere sesión; solo la dueña de la cita o el personal del salón)
reservaRouter.get(
  '/reservas/:id',
  requiereAutenticacion,
  asyncHandler(async (req, res) => {
    const reserva = await obtenerReserva(req.params.id, req.empresa?.id);
    // 404 tanto si no existe como si no tiene acceso: no se revela qué ids existen
    if (!reserva || !esDuenaOPersonal(req, reserva)) {
      return res.status(404).json({ error: 'Reserva no encontrada' });
    }
    res.json(reserva);
  })
);

// PATCH /api/reservas/:id/cancelar (requiere sesión; solo la dueña de la cita o el personal del salón)
reservaRouter.patch(
  '/reservas/:id/cancelar',
  requiereAutenticacion,
  asyncHandler(async (req, res) => {
    const existente = await obtenerReserva(req.params.id, req.empresa?.id);
    if (!existente || !esDuenaOPersonal(req, existente)) {
      return res.status(404).json({ error: 'Reserva no encontrada' });
    }
    try {
      const reserva = await cancelarReserva(req.params.id, req.empresa?.id, req.body?.motivo);
      res.json(reserva);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  })
);

// ---- Rutas de administración y estilistas ----

// GET /api/admin/reservas (con filtros por rango de fechas, cliente, servicio, estilista y estado)
adminReservaRouter.get('/reservas', requiereRol(...ROLES_AGENDA), asyncHandler(async (req, res) => {
  const {
    fecha,
    fecha_inicio,
    fecha_fin,
    cliente,
    servicio_id,
    empleada_id,
    estado,
  } = req.query as {
    fecha?: string;
    fecha_inicio?: string;
    fecha_fin?: string;
    cliente?: string;
    servicio_id?: string;
    empleada_id?: string;
    estado?: any;
  };

  // Validación de parámetros: un valor mal formado no debe llegar a la base de datos
  for (const valor of [fecha, fecha_inicio, fecha_fin]) {
    if (valor !== undefined && !FECHA_ISO.test(valor)) {
      return res.status(400).json({ error: 'Las fechas deben tener el formato YYYY-MM-DD' });
    }
  }
  if (estado && !(ESTADOS_RESERVA as readonly string[]).includes(estado)) {
    return res.status(400).json({ error: 'estado inválido' });
  }

  const where: any = {};

  // Scope a la empresa del tenant
  if (req.empresa?.id) {
    where.empresaId = req.empresa.id;
  }

  // Filtro por rango de fechas o fecha exacta
  if (fecha_inicio && fecha_fin) {
    where.fecha = {
      gte: new Date(fecha_inicio),
      lte: new Date(fecha_fin),
    };
  } else if (fecha_inicio) {
    where.fecha = {
      gte: new Date(fecha_inicio),
    };
  } else if (fecha_fin) {
    where.fecha = {
      lte: new Date(fecha_fin),
    };
  } else if (fecha) {
    where.fecha = new Date(fecha);
  }

  // Filtro por servicio
  if (servicio_id) {
    where.servicioId = servicio_id;
  }

  // Filtro por estilista asignada
  if (empleada_id) {
    where.empleadaId = empleada_id;
  }

  // Filtro por estado
  if (estado) {
    where.estado = estado;
  }

  // Filtro por cliente (nombre, teléfono o correo)
  if (cliente && cliente.trim()) {
    const term = cliente.trim();
    where.cliente = {
      OR: [
        { nombre: { contains: term, mode: 'insensitive' } },
        { telefono: { contains: term, mode: 'insensitive' } },
        { email: { contains: term, mode: 'insensitive' } },
      ],
    };
  }

  const reservas = await prisma.reserva.findMany({
    where,
    include: { cliente: true, servicio: true, diseno: true, empleada: true },
    orderBy: [{ fecha: 'asc' }, { horaInicio: 'asc' }],
  });
  res.json(reservas);
}));

// PATCH /api/admin/reservas/:id/estado
adminReservaRouter.patch(
  '/reservas/:id/estado',
  requiereRol(...ROLES_AGENDA),
  asyncHandler(async (req, res) => {
    const parsed = estadoReservaSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join(', ') });
    }
    try {
      const reserva = await cambiarEstadoReserva(req.params.id, parsed.data.estado, req.empresa?.id);
      res.json(reserva);
    } catch (err: any) {
      res.status(err.message === 'Reserva no encontrada' ? 404 : 400).json({ error: err.message });
    }
  })
);

// GET /api/admin/reportes/ocupacion
adminReservaRouter.get('/reportes/ocupacion', requiereRol(...ROLES_GESTION), asyncHandler(async (req, res) => {
  const whereEmpresa = req.empresa?.id ? { empresaId: req.empresa.id } : {};
  const total = await prisma.reserva.count({ where: whereEmpresa });
  const porEstado = await prisma.reserva.groupBy({
    by: ['estado'],
    where: whereEmpresa,
    _count: true,
  });
  res.json({ total, por_estado: porEstado });
}));
