import { Router } from 'express';
import { OAuth2Client } from 'google-auth-library';
import { prisma } from '../../config/database';
import { env } from '../../config/env';
import { requiereAutenticacion, requiereRol, firmarToken, ROLES_AGENDA } from '../../middlewares/auth.middleware';
import { compararSecretos, verificarPassword } from '../../utils/password';
import { LimitadorIntentos } from '../../utils/limitador';
import { asyncHandler } from '../../utils/async-handler';

export const authRouter = Router();

const clienteGoogle = env.GOOGLE_CLIENT_ID ? new OAuth2Client(env.GOOGLE_CLIENT_ID) : null;

// Intentos fallidos de login: por IP+usuario (fuerza bruta a una cuenta) y por IP (barrido de cuentas)
const VENTANA_LOGIN_MS = 15 * 60 * 1000;
const fallosPorUsuario = new LimitadorIntentos(5, VENTANA_LOGIN_MS);
const fallosPorIp = new LimitadorIntentos(30, VENTANA_LOGIN_MS);

// POST /api/auth/login
authRouter.post('/login', asyncHandler(async (req, res) => {
  const { usuario, password } = req.body ?? {};
  const empresa = req.empresa;

  if (typeof usuario !== 'string' || typeof password !== 'string' || !usuario.trim() || !password) {
    return res.status(400).json({ error: 'Usuario y contraseña son requeridos' });
  }

  const ip = req.ip || 'desconocida';
  const claveUsuario = `${ip}|${usuario.trim().toLowerCase()}`;
  if (fallosPorUsuario.excedido(claveUsuario) || fallosPorIp.excedido(ip)) {
    const espera = Math.max(fallosPorUsuario.segundosRestantes(claveUsuario), fallosPorIp.segundosRestantes(ip));
    res.setHeader('Retry-After', String(espera));
    return res.status(429).json({ error: 'Demasiados intentos fallidos. Intenta de nuevo más tarde.' });
  }

  const registrarFallo = () => {
    fallosPorUsuario.registrar(claveUsuario);
    fallosPorIp.registrar(ip);
    return res.status(401).json({ error: 'Credenciales inválidas' });
  };

  // 1. Administrador general definido por variables de entorno
  const okUsuario = compararSecretos(usuario, env.ADMIN_USER);
  const okPassword = compararSecretos(password, env.ADMIN_PASSWORD);
  if (okUsuario && okPassword) {
    fallosPorUsuario.limpiar(claveUsuario);
    const token = firmarToken({ usuario, rol: 'admin', empresaId: empresa?.id }, '12h');
    return res.json({
      token,
      usuario: {
        nombre: 'Administradora General',
        email: 'admin@belleslot.com',
        rol: 'admin',
        empresaId: empresa?.id,
      },
    });
  }

  // 2. Usuario de la tabla Usuario (administradora del salón o superadmin), con contraseña
  const usuarioDB = await prisma.usuario.findFirst({
    where: {
      email: { equals: usuario.trim(), mode: 'insensitive' },
      activo: true,
      rol: { in: ['admin_empresa', 'superadmin'] },
      OR: [...(empresa?.id ? [{ empresaId: empresa.id }] : []), { rol: 'superadmin' as const }],
    },
  });

  // Se verifica siempre (con un hash de relleno si no existe) para no revelar qué correos existen
  const passwordCorrecta = await verificarPassword(password, usuarioDB?.passwordHash);
  if (!usuarioDB || !passwordCorrecta) {
    return registrarFallo();
  }

  fallosPorUsuario.limpiar(claveUsuario);
  const token = firmarToken(
    {
      id: usuarioDB.id,
      usuario: usuarioDB.nombre,
      email: usuarioDB.email,
      rol: usuarioDB.rol,
      empresaId: usuarioDB.empresaId,
    },
    '12h'
  );
  return res.json({
    token,
    usuario: {
      id: usuarioDB.id,
      nombre: usuarioDB.nombre,
      email: usuarioDB.email,
      rol: usuarioDB.rol,
      empresaId: usuarioDB.empresaId,
    },
  });
}));

// POST /api/auth/google
authRouter.post('/google', asyncHandler(async (req, res) => {
  const { credential, rol = 'estilista', email: inputEmail, nombre: inputNombre, foto: inputFoto } = req.body ?? {};
  const empresa = req.empresa;

  if (rol !== 'estilista' && rol !== 'cliente') {
    return res.status(400).json({ error: 'Rol inválido' });
  }

  let email: string | undefined;
  let nombre: string | undefined;
  let foto: string | undefined;

  if (credential) {
    // Credencial de Google: se verifica la firma, la audiencia (nuestro Client ID) y la vigencia
    if (!clienteGoogle) {
      return res.status(503).json({ error: 'El acceso con Google no está configurado en el servidor (falta GOOGLE_CLIENT_ID).' });
    }
    try {
      const ticket = await clienteGoogle.verifyIdToken({
        idToken: String(credential),
        audience: env.GOOGLE_CLIENT_ID,
      });
      const perfil = ticket.getPayload();
      if (!perfil?.email || !perfil.email_verified) {
        return res.status(401).json({ error: 'La cuenta de Google no tiene un correo verificado' });
      }
      email = perfil.email;
      nombre = perfil.name || perfil.given_name;
      foto = perfil.picture;
    } catch {
      return res.status(401).json({ error: 'No se pudo verificar la cuenta de Google. Intenta nuevamente.' });
    }
  } else if (env.ALLOW_DEMO_LOGIN) {
    // Solo demostración/desarrollo: acepta los datos enviados sin verificar
    email = typeof inputEmail === 'string' ? inputEmail : undefined;
    nombre = typeof inputNombre === 'string' ? inputNombre : undefined;
    foto = typeof inputFoto === 'string' ? inputFoto : undefined;
  } else {
    return res.status(401).json({ error: 'Inicia sesión con tu cuenta de Google para continuar.' });
  }

  const emailLimpio = (email || '').toLowerCase().trim();
  if (!emailLimpio) {
    return res.status(400).json({ error: 'Se requiere un correo electrónico válido' });
  }

  const nombreSalon = empresa?.nombre || 'Belle Slot';
  if (!nombre) {
    nombre = rol === 'estilista' ? `Estilista ${nombreSalon}` : `Clienta ${nombreSalon}`;
  }

  if (rol === 'estilista') {
    // Buscar estilista autorizada en tabla Empleada por correo electrónico y empresa
    const whereEmpleada: any = {
      email: { equals: emailLimpio, mode: 'insensitive' },
    };
    if (empresa?.id) {
      whereEmpleada.empresaId = empresa.id;
    }

    const empleada = await prisma.empleada.findFirst({ where: whereEmpleada });

    // RECHAZAR acceso si no está pre-registrada por la administración del salón
    if (!empleada) {
      return res.status(403).json({
        error: `Acceso restringido: El correo "${emailLimpio}" no está registrado como estilista autorizada en ${nombreSalon}. Si formas parte del equipo, solicita a la administración que autorice tu cuenta.`,
      });
    }

    if (!empleada.activo) {
      return res.status(403).json({
        error: `La cuenta de estilista para "${empleada.nombre}" se encuentra inactiva. Comunícate con la administración de ${nombreSalon}.`,
      });
    }

    const token = firmarToken(
      { id: empleada.id, usuario: empleada.nombre, email: empleada.email, rol: 'estilista', empresaId: empresa?.id, foto },
      '24h'
    );

    return res.json({
      token,
      usuario: {
        id: empleada.id,
        nombre: empleada.nombre,
        email: empleada.email,
        telefono: empleada.telefono,
        rol: 'estilista',
        empresaId: empresa?.id,
        foto: foto || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      },
    });
  }

  // Rol cliente: las clientas sí pueden auto-registrarse al agendar citas
  const whereCliente: any = { email: { equals: emailLimpio, mode: 'insensitive' } };
  if (empresa?.id) {
    whereCliente.empresaId = empresa.id;
  }

  let cliente = await prisma.cliente.findFirst({ where: whereCliente });

  if (!cliente) {
    const telefono = typeof req.body.telefono === 'string' ? req.body.telefono.trim().slice(0, 30) : '';
    cliente = await prisma.cliente.create({
      data: {
        nombre,
        email: emailLimpio,
        telefono,
        empresaId: empresa?.id,
      },
    });
  }

  const token = firmarToken(
    { id: cliente.id, usuario: cliente.nombre, email: cliente.email ?? emailLimpio, rol: 'cliente', empresaId: empresa?.id, foto },
    '24h'
  );

  return res.json({
    token,
    usuario: {
      id: cliente.id,
      nombre: cliente.nombre,
      email: cliente.email,
      telefono: cliente.telefono,
      rol: 'cliente',
      empresaId: empresa?.id,
      foto,
    },
  });
}));

// GET /api/auth/estilistas (estilistas activas del salón; solo personal autenticado del salón).
// Para el selector público al agendar se usa GET /api/empleadas, que no expone correos.
authRouter.get('/estilistas', requiereAutenticacion, requiereRol(...ROLES_AGENDA), asyncHandler(async (req, res) => {
  const where: any = { activo: true };
  if (req.empresa?.id) {
    where.empresaId = req.empresa.id;
  }

  const estilistas = await prisma.empleada.findMany({
    where,
    select: { id: true, nombre: true, email: true },
    orderBy: { nombre: 'asc' },
  });
  res.json(estilistas);
}));

// ---- Router para Administración de Estilistas (/api/admin/estilistas) ----
// Se monta en /api/admin, ya protegido por requiereAutenticacion + rol de gestión.
export const adminEstilistasRouter = Router();

// GET /api/admin/estilistas (Lista completa con estados para panel admin del salón)
adminEstilistasRouter.get('/', asyncHandler(async (req, res) => {
  const where: any = {};
  if (req.empresa?.id) {
    where.empresaId = req.empresa.id;
  }

  const estilistas = await prisma.empleada.findMany({
    where,
    orderBy: { nombre: 'asc' },
  });
  res.json(estilistas);
}));

// POST /api/admin/estilistas (Registrar nueva estilista autorizada para el salón)
adminEstilistasRouter.post('/', asyncHandler(async (req, res) => {
  const { nombre, email, telefono } = req.body ?? {};
  const empresaId = req.empresa?.id;

  if (typeof nombre !== 'string' || typeof email !== 'string' || !nombre.trim() || !email.trim()) {
    return res.status(400).json({ error: 'El nombre y correo electrónico son requeridos' });
  }
  const emailLimpio = email.toLowerCase().trim();

  const whereExiste: any = { email: emailLimpio };
  if (empresaId) whereExiste.empresaId = empresaId;

  const existe = await prisma.empleada.findFirst({ where: whereExiste });
  if (existe) {
    return res.status(409).json({ error: 'Ya existe una estilista registrada con este correo en este salón' });
  }

  const nueva = await prisma.empleada.create({
    data: {
      nombre: nombre.trim(),
      email: emailLimpio,
      telefono: typeof telefono === 'string' && telefono.trim() ? telefono.trim() : null,
      empresaId,
      activo: true,
    },
  });
  res.status(201).json(nueva);
}));

// PATCH /api/admin/estilistas/:id/estado (Activar o desactivar estilista de ESTE salón)
adminEstilistasRouter.patch('/:id/estado', asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { activo } = req.body ?? {};
  const empresaId = req.empresa?.id;

  if (typeof activo !== 'boolean') {
    return res.status(400).json({ error: 'El campo "activo" debe ser verdadero o falso' });
  }

  // Filtrar por empresa evita modificar estilistas de otros salones conociendo su id
  const { count } = await prisma.empleada.updateMany({
    where: { id, ...(empresaId ? { empresaId } : {}) },
    data: { activo },
  });
  if (count === 0) {
    return res.status(404).json({ error: 'Estilista no encontrada' });
  }

  const actualizada = await prisma.empleada.findUnique({ where: { id } });
  res.json(actualizada);
}));
