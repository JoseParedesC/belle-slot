import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import { env } from './config/env';
import { apiRouter, adminRouter } from './routes';
import { iniciarCronRecordatorios } from './jobs/recordatorios.cron';

const app = express();

// Railway (y la mayoría de PaaS) colocan un proxy delante: sin esto req.ip sería siempre la IP del proxy
// y los límites de intentos por IP no funcionarían.
app.set('trust proxy', 1);
app.disable('x-powered-by');

// CORS: si se define CORS_ORIGINS solo esos dominios (el frontend) pueden llamar a la API desde un navegador
app.use(cors(env.CORS_ORIGINS.length > 0 ? { origin: env.CORS_ORIGINS } : undefined));

app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

app.use(express.json());

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

app.use('/api', apiRouter);
app.use('/api/admin', adminRouter);

// Manejo de errores: respuestas JSON sin detalles internos (JSON mal formado, errores no controlados)
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  if (err?.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'El cuerpo de la petición no es un JSON válido' });
  }
  if (err?.type === 'entity.too.large') {
    return res.status(413).json({ error: 'La petición es demasiado grande' });
  }
  console.error('Error no controlado:', err);
  res.status(500).json({ error: 'Error interno del servidor' });
});

// Red de seguridad: registra el error en vez de tumbar el proceso
process.on('unhandledRejection', (motivo) => {
  console.error('Promesa rechazada sin manejar:', motivo);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Backend escuchando en puerto ${PORT}`);
  iniciarCronRecordatorios();
});
