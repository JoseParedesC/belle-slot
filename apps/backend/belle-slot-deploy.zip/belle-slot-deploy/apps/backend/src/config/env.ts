/**
 * Configuración centralizada a partir de variables de entorno.
 *
 * En producción (NODE_ENV=production) el servidor NO arranca si faltan secretos
 * o si usan valores por defecto inseguros: es preferible un error claro al arrancar
 * que un sistema desplegado con credenciales conocidas.
 */
const esProduccion = process.env.NODE_ENV === 'production';

const VALORES_INSEGUROS = ['dev-secret', 'changeme', 'secret', 'admin123', 'password'];

function leer(nombre: string): string | undefined {
  const valor = process.env[nombre]?.trim();
  return valor ? valor : undefined;
}

function secreto(nombre: string, valorDesarrollo: string, largoMinimo: number): string {
  const valor = leer(nombre);

  if (esProduccion) {
    const esPlaceholder = !!valor && valor.toLowerCase().includes('cambia'); // valores de ejemplo de .env.example
    if (!valor || esPlaceholder || VALORES_INSEGUROS.includes(valor.toLowerCase()) || valor.length < largoMinimo) {
      throw new Error(
        `[config] ${nombre} es obligatoria en producción (mínimo ${largoMinimo} caracteres) y no puede ser un valor por defecto ni de ejemplo.`
      );
    }
    return valor;
  }

  if (!valor) {
    console.warn(`[config] ${nombre} no está definida: se usa un valor de desarrollo. No lo uses en producción.`);
  }
  return valor ?? valorDesarrollo;
}

function lista(nombre: string): string[] {
  return (leer(nombre) || '')
    .split(',')
    .map((v) => v.trim().replace(/\/+$/, ''))
    .filter(Boolean);
}

const permitirDemo = leer('ALLOW_DEMO_LOGIN');

export const env = {
  esProduccion,

  /** Secreto para firmar los JWT (mínimo 32 caracteres en producción). */
  JWT_SECRET: secreto('JWT_SECRET', 'dev-secret-solo-desarrollo-no-usar-en-produccion', 32),

  /** Administrador general definido por variables de entorno. */
  ADMIN_USER: leer('ADMIN_USER') || 'admin',
  ADMIN_PASSWORD: secreto('ADMIN_PASSWORD', 'admin123', 10),

  /** Client ID de Google OAuth. Si está definido, /auth/google verifica la firma del token. */
  GOOGLE_CLIENT_ID: leer('GOOGLE_CLIENT_ID'),

  /**
   * Permite iniciar sesión con Google SIN credencial verificada (solo enviando un correo).
   * Es un modo de demostración/desarrollo: por defecto solo se habilita fuera de producción.
   */
  ALLOW_DEMO_LOGIN: permitirDemo !== undefined ? permitirDemo.toLowerCase() === 'true' : !esProduccion,

  /** Orígenes (dominios del frontend) autorizados por CORS, separados por comas. Vacío = cualquiera. */
  CORS_ORIGINS: lista('CORS_ORIGINS'),
};

if (env.esProduccion && env.ALLOW_DEMO_LOGIN) {
  console.warn('[config] ALLOW_DEMO_LOGIN=true en producción: cualquiera puede entrar como estilista o clienta conociendo un correo.');
}
if (env.esProduccion && env.CORS_ORIGINS.length === 0) {
  console.warn('[config] CORS_ORIGINS no está definida: la API acepta peticiones desde cualquier origen.');
}
