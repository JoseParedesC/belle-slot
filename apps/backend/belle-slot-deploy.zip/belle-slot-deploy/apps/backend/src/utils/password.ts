import { randomBytes, scrypt as scryptCb, timingSafeEqual, createHash } from 'crypto';
import { promisify } from 'util';

const scrypt = promisify(scryptCb);
const LARGO_CLAVE = 64;

/**
 * Hash de contraseñas con scrypt (incluido en Node, sin dependencias externas).
 * Formato guardado: scrypt$<sal en hex>$<hash en hex>
 * (prisma/seed.ts usa el mismo formato: si lo cambias aquí, cámbialo allí también).
 */
export async function hashPassword(password: string): Promise<string> {
  const sal = randomBytes(16);
  const derivada = (await scrypt(password, sal, LARGO_CLAVE)) as Buffer;
  return `scrypt$${sal.toString('hex')}$${derivada.toString('hex')}`;
}

// Hash de relleno: cuando el usuario no existe se hace el mismo trabajo para que
// el tiempo de respuesta no revele qué correos están registrados.
const HASH_RELLENO = `scrypt$${'00'.repeat(16)}$${'00'.repeat(LARGO_CLAVE)}`;

export async function verificarPassword(password: string, hashGuardado?: string | null): Promise<boolean> {
  const partes = (hashGuardado || '').split('$');
  const valido = partes.length === 3 && partes[0] === 'scrypt';
  const [, salHex, hashHex] = valido ? partes : HASH_RELLENO.split('$');

  const esperado = Buffer.from(hashHex, 'hex');
  const derivada = (await scrypt(password, Buffer.from(salHex, 'hex'), esperado.length)) as Buffer;

  const coincide = esperado.length === derivada.length && timingSafeEqual(esperado, derivada);
  return valido && coincide;
}

/** Comparación de secretos en tiempo constante (independiente de la longitud). */
export function compararSecretos(a: string, b: string): boolean {
  const ha = createHash('sha256').update(a).digest();
  const hb = createHash('sha256').update(b).digest();
  return timingSafeEqual(ha, hb);
}
