import { Request, Response, NextFunction } from 'express';

/**
 * Express 4 no captura los errores de los handlers async: sin esto, una excepción
 * no controlada se convierte en un "unhandled rejection" que puede tumbar el proceso.
 * Envuelve el handler para enviar el error al middleware de errores.
 */
export const asyncHandler =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => {
    fn(req, res, next).catch(next);
  };
