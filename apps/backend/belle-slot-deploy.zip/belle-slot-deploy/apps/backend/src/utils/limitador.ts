import { Request, Response, NextFunction } from 'express';

/**
 * Limitador de intentos en memoria (ventana fija). Suficiente para una sola instancia
 * del backend; si se escala a varias réplicas habría que usar un almacén compartido (p. ej. Redis).
 */
export class LimitadorIntentos {
  private registros = new Map<string, { cuenta: number; inicio: number }>();

  constructor(
    private readonly max: number,
    private readonly ventanaMs: number
  ) {}

  private vigente(clave: string) {
    const registro = this.registros.get(clave);
    if (!registro) return undefined;
    if (Date.now() - registro.inicio >= this.ventanaMs) {
      this.registros.delete(clave);
      return undefined;
    }
    return registro;
  }

  excedido(clave: string): boolean {
    const registro = this.vigente(clave);
    return !!registro && registro.cuenta >= this.max;
  }

  segundosRestantes(clave: string): number {
    const registro = this.vigente(clave);
    if (!registro) return 0;
    return Math.max(1, Math.ceil((registro.inicio + this.ventanaMs - Date.now()) / 1000));
  }

  registrar(clave: string): void {
    const registro = this.vigente(clave);
    if (registro) {
      registro.cuenta += 1;
      return;
    }
    if (this.registros.size >= 10000) this.limpiarVencidos();
    this.registros.set(clave, { cuenta: 1, inicio: Date.now() });
  }

  limpiar(clave: string): void {
    this.registros.delete(clave);
  }

  private limpiarVencidos() {
    const ahora = Date.now();
    for (const [clave, registro] of this.registros) {
      if (ahora - registro.inicio >= this.ventanaMs) this.registros.delete(clave);
    }
    // Tope de memoria: si aun así hay demasiadas claves, se reinicia el contador
    if (this.registros.size >= 10000) this.registros.clear();
  }
}

/** Middleware que cuenta cada petición por IP y responde 429 al superar el límite. */
export function limitarPorIp(limitador: LimitadorIntentos) {
  return (req: Request, res: Response, next: NextFunction) => {
    const clave = req.ip || 'desconocida';
    if (limitador.excedido(clave)) {
      res.setHeader('Retry-After', String(limitador.segundosRestantes(clave)));
      return res.status(429).json({ error: 'Demasiadas solicitudes. Intenta de nuevo más tarde.' });
    }
    limitador.registrar(clave);
    next();
  };
}
