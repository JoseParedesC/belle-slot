# Belle Slot — Backend

API REST multi-empresa (multi-tenant) para gestionar reservas de salones de manicure y estética. Cada salón (*empresa*) tiene sus propios servicios, diseños, estilistas, clientes, horarios y reservas, todos aislados por un identificador único (`slug`).

## Contenido

1. [Funcionalidades](#funcionalidades)
2. [Stack y estructura](#stack-y-estructura)
3. [Puesta en marcha local](#puesta-en-marcha-local)
4. [Variables de entorno](#variables-de-entorno)
5. [Base de datos: migraciones y seed](#base-de-datos-migraciones-y-seed)
6. [Multi-tenant: cómo se identifica el salón](#multi-tenant-cómo-se-identifica-el-salón)
7. [Autenticación y permisos](#autenticación-y-permisos)
8. [Disponibilidad de horarios](#disponibilidad-de-horarios)
9. [Configurar horarios, días y temporadas](#configurar-horarios-días-y-temporadas)
10. [Referencia de endpoints](#referencia-de-endpoints)
11. [Recordatorios y notificaciones](#recordatorios-y-notificaciones)
12. [Despliegue en Railway](#despliegue-en-railway)
13. [Solución de problemas](#solución-de-problemas)
14. [Seguridad y limitaciones](#seguridad-y-limitaciones)

---

## Funcionalidades

- **Multi-empresa (SaaS):** varios salones en la misma instancia, aislados por `slug`. Incluye directorio público de salones y registro de nuevos salones.
- **Catálogo:** servicios (con duración y precio base) y diseños (con incremento de precio, opcionalmente ligados a un servicio).
- **Disponibilidad inteligente:** calcula las horas reservables según los días de atención, los turnos configurados (incluida la pausa de almuerzo), horarios por temporada, la duración del servicio y las citas ya reservadas. Devuelve **todas** las horas del día indicando cuáles están libres y cuáles bloqueadas.
- **Agenda por profesional:** cada estilista tiene su propia disponibilidad. La clienta puede elegir con quién agendar o dejar «cualquiera disponible», y el servidor asigna a la profesional libre con menos carga ese día.
- **Reservas:** creación con revalidación de disponibilidad y asignación de profesional en el servidor, cancelación, consulta por cliente y cambio de estado (`completada`, `no_asistio`). Las inasistencias se acumulan por cliente.
- **Panel de administración:** listado de reservas con filtros, gestión de estilistas autorizadas, edición de la configuración del salón y reporte de ocupación.
- **Autenticación y permisos por rol:** login de administración con contraseña, acceso con Google verificado para estilistas y clientas, y sesiones que solo valen en el salón donde se emitieron.
- **Recordatorios automáticos:** tarea programada que avisa 24 h y 2 h antes de la cita y registra cada envío.

---

## Stack y estructura

Node.js 20 · TypeScript · Express · Prisma (PostgreSQL) · Zod · JWT · node-cron

```
apps/backend
├── prisma/
│   ├── schema.prisma          # Modelo de datos
│   ├── migrations/            # Migraciones versionadas (se aplican con migrate deploy)
│   └── seed.ts                # Datos iniciales (empresas, servicios, estilistas, usuarios)
├── src/
│   ├── main.ts                # Arranque de Express, CORS, rutas y cron
│   ├── routes/index.ts        # Montaje de routers (públicos y /admin)
│   ├── middlewares/
│   │   ├── tenant.middleware.ts   # Resuelve la empresa de cada petición
│   │   └── auth.middleware.ts     # Valida el JWT en rutas /admin
│   ├── modules/
│   │   ├── auth/              # Login, acceso con Google, gestión de estilistas
│   │   ├── saas/              # Directorio y registro de salones
│   │   ├── configuracion/     # Datos y horarios del salón
│   │   ├── servicios/  disenos/  clientes/  empleadas/
│   │   ├── reservas/          # Controlador, servicio, esquema Zod y disponibilidad
│   │   └── notificaciones/    # Cliente HTTP del microservicio de notificaciones
│   └── jobs/recordatorios.cron.ts
└── Dockerfile
```

---

## Puesta en marcha local

Requisitos: Node.js 20+ y una base PostgreSQL.

```bash
cd apps/backend
cp .env.example .env            # ajusta DATABASE_URL y los secretos
npm install
npx prisma generate
npx prisma migrate deploy       # crea las tablas (o `npm run prisma:migrate` en desarrollo)
npx prisma db seed              # carga los datos iniciales
npm run dev                     # http://localhost:3000
```

Scripts disponibles:

| Script | Descripción |
|---|---|
| `npm run dev` | Servidor en modo desarrollo con recarga (`ts-node-dev`). |
| `npm run build` | Compila TypeScript a `dist/`. |
| `npm start` | Ejecuta el build compilado (`node dist/main.js`). |
| `npm run prisma:generate` | Regenera el cliente de Prisma. |
| `npm run prisma:migrate` | Crea/aplica migraciones en desarrollo (`prisma migrate dev`). |

Comprobación rápida: `GET /health` responde `{"status":"ok"}`.

---

## Variables de entorno

| Variable | Obligatoria | Descripción |
|---|---|---|
| `DATABASE_URL` | Sí | Cadena de conexión a PostgreSQL. |
| `PORT` | No | Puerto HTTP (por defecto `3000`; Railway lo inyecta). |
| `JWT_SECRET` | **Sí en producción** | Secreto para firmar las sesiones. Mínimo 32 caracteres. Genera uno con `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`. |
| `ADMIN_USER` / `ADMIN_PASSWORD` | **Sí en producción** | Credenciales del administrador general. `ADMIN_PASSWORD` con mínimo 10 caracteres y distinta de valores comunes (`admin123`, `password`…). |
| `GOOGLE_CLIENT_ID` | Recomendada | Client ID de Google OAuth (el mismo del frontend, `VITE_GOOGLE_CLIENT_ID`). Con él, `/auth/google` verifica la firma, la audiencia y la vigencia del token de Google. |
| `CORS_ORIGINS` | Recomendada | Dominios del frontend permitidos, separados por comas y sin barra final (`https://app.up.railway.app,https://misalon.com`). Vacía = acepta cualquier origen. |
| `ALLOW_DEMO_LOGIN` | No | `true` permite entrar como estilista/clienta enviando solo un correo, sin verificar Google (modo demostración). Por defecto es `true` fuera de producción y `false` en producción. |
| `NOTIFICACIONES_SERVICE_URL` | No | URL del microservicio que envía correos/WhatsApp (por defecto `http://localhost:3001`). |
| `TIMEZONE_NEGOCIO` | No | Zona horaria IANA usada para bloquear las horas que ya pasaron hoy (por defecto `America/Bogota`). El servidor corre en UTC, por eso se calcula explícitamente. |
| `SEED_ADMIN_PASSWORD` | Solo para el seed | Contraseña de los usuarios de ejemplo. Sin ella esos usuarios quedan sin contraseña y no pueden iniciar sesión. |

> **Arranque seguro:** con `NODE_ENV=production` (lo fija el `Dockerfile`) el servidor **no arranca** si `JWT_SECRET` o `ADMIN_PASSWORD` faltan, son demasiado cortos o usan un valor por defecto. El log indica cuál variable corregir.

---

## Base de datos: migraciones y seed

- Las migraciones viven en `prisma/migrations/` y se aplican con `npx prisma migrate deploy`. El `Dockerfile` ya lo ejecuta al arrancar el contenedor.
- **Cada cambio en `schema.prisma` necesita su migración** (`npx prisma migrate dev --name descripcion`) y esa carpeta debe subirse al repositorio. Si el schema va por delante de las migraciones, las tablas nuevas no existirán en producción (error `P2021`).
- El **seed** (`prisma/seed.ts`) es idempotente (usa `upsert`) y se ejecuta con `npx prisma db seed`. Requiere el paquete **`tsx`** en `devDependencies`:

  ```bash
  npm install -D tsx
  ```

  Crea dos salones de ejemplo (`dahood24` y `jc-nails`), sus servicios, diseños y estilistas, y estos usuarios: `superadmin@saas.local`, `admin@dahood24.local` y `admin@jcnails.local`, a los que se asigna la contraseña de `SEED_ADMIN_PASSWORD` (guardada con hash scrypt). Define esa variable antes del seed si quieres usarlos. El salón `jc-nails` incluye un horario por temporada con pausa de almuerzo.

---

## Multi-tenant: cómo se identifica el salón

Todas las rutas (salvo `/api/saas/*` y `/health`) pasan por `resolverTenant`, que determina la empresa con este orden de prioridad:

1. Header `x-tenant-slug`
2. Parámetro de ruta `:slug` / `:empresaSlug`
3. Query `?empresa_slug=` o `?tenant=`
4. Valor por defecto: `belle-slot`

Si el slug no existe responde `404`; si la empresa está inactiva, `403`. Toda consulta de servicios, reservas, clientes, estilistas y configuración se filtra por la empresa resuelta.

```bash
curl -H "x-tenant-slug: jc-nails" http://localhost:3000/api/servicios
```

---

## Autenticación y permisos

Las rutas `/api/admin/*` (y las que escriben datos) exigen el header `Authorization: Bearer <token>`. El orden de validación es siempre: identificar el salón → validar la sesión → comprobar el rol.

### Roles

| Rol | Cómo entra | Qué puede hacer |
|---|---|---|
| `admin` | `ADMIN_USER`/`ADMIN_PASSWORD` (variables de entorno) | Gestión completa del salón donde inició sesión. |
| `admin_empresa` | Correo + contraseña (tabla `Usuario`) | Gestión completa de su salón. |
| `superadmin` | Correo + contraseña (tabla `Usuario`) | Gestión de cualquier salón. |
| `estilista` | Google (correo pre-autorizado en el salón) | Ver y actualizar la agenda de reservas de su salón. |
| `cliente` | Google | Ver y cancelar **sus propias** reservas. |

- **Gestión** = configuración, servicios/diseños (crear), clientas, estilistas, reportes y agenda.
- **Agenda** = listar reservas y cambiar su estado (gestión + estilistas).
- Una sesión **solo vale en el salón donde se emitió** (`empresaId` del token frente al `x-tenant-slug` de la petición): responde `403` si se usa en otro. El `superadmin` es la excepción.
- Los tokens se firman con HS256 y se rechazan los sin firma, falsificados o vencidos.

### Administrador — `POST /api/auth/login`

```json
{ "usuario": "admin@jcnails.local", "password": "********" }
```

Acepta las credenciales de `ADMIN_USER`/`ADMIN_PASSWORD` o el correo y la contraseña de un `Usuario` con rol `admin_empresa` o `superadmin`. La contraseña se verifica siempre contra un hash scrypt (con un hash de relleno si el usuario no existe, para no revelar qué correos están registrados). El token dura 12 h. Tras 5 intentos fallidos por IP y usuario (o 30 por IP) en 15 minutos responde `429` con `Retry-After`.

### Google — `POST /api/auth/google`

```json
{ "credential": "<ID token de Google>", "rol": "estilista" }
```

- Con `GOOGLE_CLIENT_ID` configurado, el servidor **verifica el token con Google** y toma el correo y el nombre del token (nunca de campos enviados por el cliente). El correo debe estar verificado por Google.
- `rol: "estilista"`: solo entra si el correo está pre-registrado y activo en el salón (lo gestiona el administrador en `/api/admin/estilistas`).
- `rol: "cliente"`: si no existe, la clienta se registra automáticamente.
- Sin `credential`, solo se acepta si `ALLOW_DEMO_LOGIN=true` (desarrollo/demostración). En producción responde `401`.
- El token dura 24 h.

---

## Disponibilidad de horarios

La lógica está en `src/modules/reservas/disponibilidad.service.ts`, dividida en funciones reutilizables:

| Función | Tipo | Qué hace |
|---|---|---|
| `atiendeEnFecha(diasAtencion, fecha)` | pura | Indica si el salón atiende ese día de la semana (ignora tildes y mayúsculas). |
| `resolverTurnos(config, mes)` | pura | Devuelve los rangos horarios del mes. Prioridad: temporada estacional → `personalizacion.turnos` → pausa de almuerzo → horario continuo. |
| `generarHorasDeInicio(turnos, duracion, bloque)` | pura | Genera cada hora de inicio posible. Una cita solo es válida si **termina dentro del mismo turno**, por eso nunca se ofrecen horas que crucen el almuerzo. |
| `marcarBloqueos(horas, duracion, citas, opciones)` | pura | Marca cada hora como disponible, `ocupado` (se cruza con una cita) o `pasada` (ya transcurrió hoy). `opciones` = `{ empleadasActivas, empleadaId?, minutosMinimos? }` y define si la agenda es del salón, de una profesional o «cualquiera». |
| `elegirEmpleadaLibre(hora, duracion, citas, empleadasActivas)` | pura | Elige a la profesional libre con menos citas ese día (o `null` si ninguna lo está). |
| `calcularSlotsDelDia(fecha, servicioId, empresaId?, empleadaId?)` | BD | Función principal: devuelve todas las horas del día con su estado. |
| `calcularDisponibilidad(fecha, servicioId, empresaId?, empleadaId?)` | BD | Solo las horas libres (`string[]`). |
| `resolverAsignacion(fecha, servicioId, hora, empresaId?, empleadaId?)` | BD | Revalida una hora y resuelve qué profesional atenderá. La usa `crearReserva` en el servidor. |

Reglas de cálculo:

- La duración del servicio (`duracionMinutos`) determina qué horas caben y cuánto tiempo bloquea una cita.
- El intervalo entre horas ofrecidas es `duracionBloqueMinutos` de la empresa (30 por defecto).
- Solo bloquean las reservas en estado `pendiente` o `confirmada`; las canceladas liberan el horario.
- Un día en que el salón no atiende devuelve una lista vacía.
- Hoy se bloquean además las horas anteriores a la actual, y una fecha pasada queda bloqueada por completo.

### Disponibilidad por profesional

La agenda depende de cuántas profesionales **activas** tenga el salón (`Empleada.activo`):

| Situación | Una hora está disponible cuando… |
|---|---|
| Se pide una profesional concreta (`empleada_id`) | esa profesional no tiene ninguna cita que se cruce con la hora. |
| «Cualquiera disponible» (sin `empleada_id`) | al menos una profesional activa está libre. |
| El salón no tiene profesionales registradas | no hay ninguna cita del salón que se cruce (comportamiento anterior). |

Al crear una reserva sin elegir profesional, el servidor asigna la profesional libre con menos citas ese día (en empate, el orden alfabético) y la guarda en `empleadaId`. Las citas antiguas que nunca tuvieron profesional asignada ocupan una plaza de «cualquiera disponible» pero no bloquean a ninguna profesional en concreto. Los horarios de atención (turnos, almuerzo, temporadas) siguen siendo comunes a todo el salón.

### `GET /api/disponibilidad?fecha=YYYY-MM-DD&servicio_id=<uuid>&empleada_id=<uuid>`

`empleada_id` es opcional: con él se calcula la agenda de esa profesional; sin él, «cualquiera disponible». Si la profesional no existe, no es del salón o está inactiva responde `400`.

```bash
curl -H "x-tenant-slug: jc-nails" \
  "http://localhost:3000/api/disponibilidad?fecha=2026-10-05&servicio_id=<uuid>"
```

```json
{
  "fecha": "2026-10-05",
  "servicio_id": "…",
  "empleada_id": null,
  "horarios": [
    { "hora": "09:00", "disponible": true },
    { "hora": "10:30", "disponible": false, "motivo": "ocupado" },
    { "hora": "13:00", "disponible": true }
  ],
  "horarios_disponibles": ["09:00", "13:00"]
}
```

- `horarios`: todas las horas dentro de los rangos configurados, con su estado. Úsalo para pintar botones y deshabilitar los bloqueados. `motivo` es `ocupado` o `pasada`.
- `horarios_disponibles`: solo las libres (compatibilidad con clientes anteriores).

---

## Configurar horarios, días y temporadas

Se configura por empresa con `PATCH /api/admin/configuracion` (requiere token). Los campos que definen la disponibilidad:

| Campo | Ejemplo | Efecto |
|---|---|---|
| `diasAtencion` | `["Lunes","Martes","Sábado"]` | Días que atiende. Los demás se muestran cerrados. |
| `horarioApertura` / `horarioCierre` | `"09:00"` / `"18:00"` | Horario continuo por defecto. |
| `duracionBloqueMinutos` | `30` | Intervalo entre horas de inicio ofrecidas. |
| `horasAnticipacionCancelacion` | `12` | Horas mínimas de anticipación para cancelar. |
| `personalizacion` | ver abajo | JSON libre con turnos, temporadas y pausa de almuerzo. |

### Pausa de almuerzo y temporadas

Los turnos son rangos independientes; el espacio entre ellos (el almuerzo) nunca genera horas reservables. Dentro de `personalizacion`:

```json
{
  "horarioEstacional": {
    "activo": true,
    "temporadas": [
      {
        "nombre": "feb-oct",
        "meses": [2, 3, 4, 5, 6, 7, 8, 9, 10],
        "turnos": [
          { "inicio": "09:00", "fin": "12:00" },
          { "inicio": "13:00", "fin": "19:00" }
        ]
      },
      {
        "nombre": "nov-dic",
        "meses": [11, 12],
        "turnos": [{ "inicio": "09:00", "fin": "19:00" }]
      }
    ]
  }
}
```

Alternativas más simples cuando no se usan temporadas: `personalizacion.turnos` (lista de turnos fija) o `personalizacion.pausaAlmuerzo` (`{ "inicio": "12:00", "fin": "13:00" }`, que parte el horario general en dos turnos).

> **Importante:** `PATCH` reemplaza el campo `personalizacion` completo, no lo mezcla. Envía siempre el objeto entero (por ejemplo `{ ...personalizacionActual, horarioEstacional: {...} }`) para no borrar otras claves como `instagram` o `textoHorario`.

`GET /api/configuracion` devuelve los datos actuales del salón (nombre, contacto, horarios, colores y `personalizacion`).

---

## Referencia de endpoints

Prefijo `/api`. Salvo `/saas/*`, todas necesitan resolver el salón (ver [Multi-tenant](#multi-tenant-cómo-se-identifica-el-salón)).

### Públicos (sin sesión)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/saas/empresas` | Directorio de salones activos. |
| GET | `/saas/empresas/:slug` | Perfil público de un salón. |
| POST | `/saas/empresas` | Registro de un nuevo salón. `nombre` obligatorio; si se indica `adminEmail` también `adminPassword` (mín. 8 caracteres). Máximo 5 registros por hora e IP. `409` si el slug o el correo ya existen. |
| GET | `/servicios` | Servicios activos del salón, ordenados por precio. |
| GET | `/servicios/:id/disenos` | Diseños de un servicio (más los genéricos). |
| GET | `/disenos` | Lista de diseños. |
| GET | `/empleadas` | Profesionales activas del salón para elegir al agendar (solo `id` y `nombre`). |
| GET | `/configuracion` | Datos y horarios del salón. |
| GET | `/disponibilidad` | Horas del día con su estado, opcionalmente por profesional (ver arriba). |
| POST | `/reservas` | Crea una reserva (no requiere cuenta). |
| POST | `/auth/login` · `/auth/google` | Autenticación. |

### Con sesión de clienta o personal

| Método | Ruta | Quién | Descripción |
|---|---|---|---|
| GET | `/reservas/cliente/mis-reservas` | `cliente` | Devuelve las reservas del correo de su sesión. La gestión puede consultar por `?email=` o `?telefono=`. |
| GET | `/reservas/:id` | dueña de la cita o personal del salón | Detalle de una reserva. Responde `404` si no existe o no tienes acceso. |
| PATCH | `/reservas/:id/cancelar` | dueña de la cita o personal del salón | Cancela una reserva (`{ "motivo": "…" }` opcional). No permite cancelar citas ya completadas o con inasistencia. |
| GET | `/auth/estilistas` | agenda | Estilistas activas con su correo (para el panel de estilistas). |

Solo las **lecturas** de servicios, diseños y configuración son públicas. `POST /servicios`, `POST /disenos` y `PATCH /configuracion` requieren rol de gestión.

### Crear una reserva — `POST /api/reservas`

```json
{
  "cliente": { "nombre": "Ana Pérez", "telefono": "3001234567", "email": "ana@correo.com" },
  "servicio_id": "<uuid>",
  "diseno_id": "<uuid, opcional>",
  "empleada_id": "<uuid, opcional>",
  "fecha": "2026-10-05",
  "hora_inicio": "09:00"
}
```

`empleada_id` es opcional. El servidor revalida la disponibilidad antes de guardar: si la hora ya no está libre responde `400` con `"El horario seleccionado ya no está disponible"` (o `"…con esta profesional"` si se eligió una). Si no se indica profesional, asigna la libre con menos carga; la reserva devuelta incluye `empleadaId`. Calcula `horaFin` con la duración del servicio, el `precioEstimado` (precio base + incremento del diseño), crea la reserva en estado `pendiente`, registra o reutiliza a la clienta y dispara la notificación de confirmación sin bloquear la respuesta.

### Administración (`Authorization: Bearer <token>`, salón indicado con `x-tenant-slug`)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/admin/reservas` *(agenda)* | Reservas con filtros: `fecha`, `fecha_inicio`, `fecha_fin` (`YYYY-MM-DD`), `cliente`, `servicio_id`, `empleada_id`, `estado`. |
| PATCH | `/admin/reservas/:id/estado` *(agenda)* | Cambia el estado (`pendiente`, `confirmada`, `completada`, `cancelada`, `no_asistio`). Marcar `no_asistio` suma una inasistencia a la clienta, una sola vez. Solo actúa sobre reservas del salón. |
| GET | `/admin/reportes/ocupacion` | Total de reservas y desglose por estado. |
| GET | `/admin/clientes` · `/admin/clientes/:id` | Clientas del salón. |
| GET | `/admin/estilistas` | Lista completa de estilistas con su estado. |
| POST | `/admin/estilistas` | Autoriza una estilista (`nombre` y `email` obligatorios; `409` si el correo ya existe). |
| PATCH | `/admin/estilistas/:id/estado` | Activa o revoca el acceso (`{ "activo": true }`). |
| GET · PATCH | `/admin/configuracion` | Lee o actualiza la configuración del salón. |

Estados de una reserva: `pendiente`, `confirmada`, `completada`, `cancelada`, `no_asistio`.

---

## Recordatorios y notificaciones

`src/jobs/recordatorios.cron.ts` corre **cada 15 minutos** y busca reservas `pendiente`/`confirmada` que estén a ~24 h y ~2 h de comenzar y cuyo recordatorio aún no se haya enviado. Por cada una llama al microservicio de notificaciones (`POST {NOTIFICACIONES_SERVICE_URL}/send-reminder`), marca el recordatorio como enviado y guarda el intento (canal, tipo, estado) en la tabla `Notificacion`. Si el envío falla queda registrado como `fallido` y no interrumpe el flujo de la reserva.

---

## Despliegue en Railway

1. Crea el servicio de PostgreSQL y el servicio del backend en el mismo proyecto.
2. En el backend define `DATABASE_URL` (referencia al Postgres), `JWT_SECRET` (≥ 32 caracteres), `ADMIN_USER`, `ADMIN_PASSWORD` (≥ 10 caracteres), `GOOGLE_CLIENT_ID`, `CORS_ORIGINS` (dominio público del frontend) y, si aplica, `NOTIFICACIONES_SERVICE_URL` y `TIMEZONE_NEGOCIO`. **Sin `JWT_SECRET` y `ADMIN_PASSWORD` válidos el servicio no arranca.**
3. El `Dockerfile` compila el proyecto y arranca con `npx prisma migrate deploy && node dist/main.js`, así que las migraciones se aplican en cada despliegue.
4. Genera el dominio público en *Settings → Networking*. El frontend debe apuntar a él con `VITE_API_URL=https://<dominio>/api` (Vite lo incorpora en el build: hace falta un **redeploy** del frontend al cambiarlo).
5. Los hosts `*.railway.internal` solo funcionan entre servicios del proyecto; el navegador no puede usarlos.
6. Para cargar los datos iniciales, ejecuta `SEED_ADMIN_PASSWORD='…' npx prisma db seed` en el entorno del backend (`tsx` ya está en `devDependencies`).
7. En el frontend define `VITE_GOOGLE_CLIENT_ID` (mismo valor que `GOOGLE_CLIENT_ID`); con él se oculta el formulario de acceso de demostración.

---

## Solución de problemas

| Síntoma | Causa y solución |
|---|---|
| El servicio no arranca: «JWT_SECRET es obligatoria en producción…» | Define `JWT_SECRET` (≥ 32 caracteres) y `ADMIN_PASSWORD` (≥ 10) en las variables del servicio. |
| `403` «No tienes acceso a este salón» | La sesión se emitió en otro salón. Inicia sesión de nuevo en el salón correcto (`x-tenant-slug`). |
| `401` «Inicia sesión con tu cuenta de Google» | El acceso demo está desactivado (producción). Configura `GOOGLE_CLIENT_ID` en backend y `VITE_GOOGLE_CLIENT_ID` en el frontend, o activa `ALLOW_DEMO_LOGIN=true` solo para pruebas. |
| `429` al iniciar sesión | Demasiados intentos fallidos; espera el tiempo de `Retry-After` (hasta 15 min). |
| Un usuario de la tabla `Usuario` no puede entrar | Necesita contraseña (`passwordHash`). Vuelve a ejecutar el seed con `SEED_ADMIN_PASSWORD` o crea el salón indicando `adminPassword`. |
| `spawn tsx ENOENT` al hacer seed | Falta `tsx`. Instálalo con `npm install -D tsx` y confirma que está en `package.json`. |
| `P2021: table public.empresa does not exist` | El schema tiene modelos que ninguna migración crea. Genera la migración faltante con `prisma migrate dev` y súbela al repositorio. |
| `migrate deploy` dice «No pending migrations» pero faltan tablas | El historial de `_prisma_migrations` no coincide con la base. Revisa con `npx prisma migrate status` y compara con `\dt`. |
| `404` «El salón … no fue encontrado» | Slug inexistente. Verifica el header `x-tenant-slug` y que el seed se haya ejecutado. |
| La reserva devuelve «El horario seleccionado ya no está disponible» | Otra persona reservó esa hora (con esa profesional), ya pasó, o cae fuera de los turnos. Vuelve a pedir `/disponibilidad`. |
| «La profesional seleccionada no está disponible» | El `empleada_id` no existe, es de otro salón o la profesional está inactiva. |
| El selector de profesional no aparece al agendar | El salón no tiene profesionales activas; se agenda con la agenda del salón. Autorízalas en `/api/admin/estilistas`. |
| Las horas de hoy se bloquean a destiempo | Ajusta `TIMEZONE_NEGOCIO` a la zona horaria del salón. |

---

## Seguridad y limitaciones

### Medidas implementadas

- **Rutas de escritura protegidas:** `POST /servicios`, `POST /disenos`, `PATCH /configuracion` y toda la administración (`/api/admin/*`, incluida la lista de clientas) exigen sesión y rol de gestión; ya no se exponen sin autenticación.
- **Contraseñas reales:** el login con la tabla `Usuario` verifica un hash scrypt con sal; ya no basta con conocer el correo. Comparación de secretos en tiempo constante.
- **Google verificado:** con `GOOGLE_CLIENT_ID`, el token se valida con `google-auth-library` (firma, audiencia, vigencia y correo verificado). El correo y el nombre salen del token, no del cuerpo de la petición.
- **Roles y aislamiento por salón:** cada ruta declara los roles permitidos y el token solo sirve en el salón donde se emitió. Las consultas y actualizaciones de reservas, clientas y estilistas se filtran por salón (no se pueden tocar registros de otro salón conociendo su id).
- **Reservas privadas:** consultar o cancelar una reserva y listar «mis reservas» requiere sesión; una clienta solo accede a las suyas.
- **Registro de salones:** limitado por IP, con validación de datos, y nunca reasigna ni modifica una cuenta existente.
- **Fuerza bruta:** límite de intentos fallidos de login por IP y usuario.
- **Arranque seguro:** sin `JWT_SECRET` y `ADMIN_PASSWORD` robustos, el servidor no inicia en producción.
- **CORS configurable** con `CORS_ORIGINS`, cabeceras `X-Content-Type-Options` y `Referrer-Policy`, sin `X-Powered-By`, y errores en JSON sin detalles internos. Los handlers async ya no pueden tumbar el proceso con una excepción no controlada.
- **`GET /api/empleadas`** para el selector público solo expone `id` y `nombre`; los correos de las estilistas solo los ve el personal autenticado.

### Limitaciones conocidas

- **El administrador de variables de entorno es global:** `ADMIN_USER`/`ADMIN_PASSWORD` permiten entrar a cualquier salón (queda limitado al salón elegido al iniciar sesión). Para acceso por salón usa usuarios `admin_empresa` con contraseña.
- **Sesiones sin revocación:** los tokens (12 h/24 h) no se pueden invalidar antes de vencer; no hay refresh tokens. El frontend los guarda en `localStorage`, por lo que un XSS en el frontend los expondría.
- **Límite de intentos en memoria:** funciona con una sola instancia del backend; con varias réplicas hay que moverlo a un almacén compartido (p. ej. Redis). Los contadores se reinician al redeployar.
- **Las clientas sin cuenta no pueden consultar sus citas** (solo reciben la confirmación al reservar); deben iniciar sesión con Google usando el mismo correo de la reserva.
- **`POST /api/reservas` es anónimo** (por diseño, para agendar sin cuenta): no hay verificación de correo/teléfono ni límite de reservas por persona.
- **Registro público de salones** sin verificación de correo (solo limitado por IP).
- **Reservas simultáneas:** la validación de disponibilidad y la creación no son atómicas; dos solicitudes idénticas en el mismo instante podrían crear una cita doble.
- **Horario de trabajo común:** la disponibilidad se lleva por profesional, pero los turnos y días de atención son los mismos para todas (no hay horario, descansos ni servicios distintos por estilista).
- **Sin reasignación:** no hay endpoint para cambiar la profesional de una reserva ya creada.
- **Sin fechas bloqueadas puntuales** (feriados, vacaciones): hoy solo se configuran días de la semana y temporadas por mes.
- **Mensajes de error 500** de algunas rutas antiguas aún pueden incluir el texto del error interno; conviene unificarlos con el manejador global.
